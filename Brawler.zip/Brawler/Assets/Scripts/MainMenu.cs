﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/*
 * Brawler
 * By Collin Vaille and Ravi Tata
 * The fighting that God intended.
 * */

public class MainMenu : MonoBehaviour
{
    public enum MenuScreens { TitleScreen = 0, MainMenu = 1, Credits = 2 }

    private GameObject currentMenuScreen;
    public GameObject[] menuScreens;

    public AudioSource sfxPlayer;
    public AudioClip buttonClick, mouseOver;

    // Start is called before the first frame update
    void Start ()
    {
        //The first menu screen is the title screen
        currentMenuScreen = menuScreens[(int)(MenuScreens.TitleScreen)];
    }

    // Update is called once per frame
    void Update()
    {
        //If screen is title screen
        if (currentMenuScreen == menuScreens[(int)MenuScreens.TitleScreen])
        {
            if (Input.anyKeyDown)
                GoToMenuScreen(menuScreens[(int)MenuScreens.MainMenu]);
        }
        else if (currentMenuScreen == menuScreens[(int)MenuScreens.MainMenu]) //Current screen is main menu
        {
            //GetButton returns true for every frame it is held down
            //GetButtonDown returns true only on the first frame it is pressed
            if (Input.GetButtonDown("Back"))
                GoToMenuScreen(menuScreens[(int)MenuScreens.TitleScreen]);
        }
    }

    public void OnUIMouseOver ()
    {
        sfxPlayer.PlayOneShot(mouseOver);
    }

    //Called by buttons when they're clicked and performs the action associated with them
    public void OnUIButtonClick (Transform buttonTransform)
    {
        string buttonName = buttonTransform.name;

        sfxPlayer.PlayOneShot(buttonClick);

        if (currentMenuScreen == menuScreens[(int)MenuScreens.MainMenu])
        {
            if (buttonName.Equals("Play Button"))
            {
                Debug.Log("fnewifjiwew");
            }
            else if (buttonName.Equals("Credits Button"))
                GoToMenuScreen(menuScreens[(int)MenuScreens.Credits]);
            else if (buttonName.Equals("Quit Button"))
            {
                Application.Quit();
            }
        }
        else if (currentMenuScreen == menuScreens[(int)MenuScreens.Credits])
        {
            if (buttonName.Equals("Back Button"))
                GoToMenuScreen(menuScreens[(int)MenuScreens.MainMenu]);
        }
    }

    private void GoToMenuScreen (GameObject screenToGoTo)
    {
        //Turn off previous menu screen
        currentMenuScreen.SetActive(false);

        //Current screen is now title sceen
        currentMenuScreen = screenToGoTo;

        //Turn on the new screen
        currentMenuScreen.SetActive(true);
    }
}
